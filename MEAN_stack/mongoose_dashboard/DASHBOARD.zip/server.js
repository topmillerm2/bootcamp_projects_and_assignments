var express = require('express');

var app = express();

var bodyParser = require('body-parser');

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/elephants')
var ElephantSchema = new mongoose.Schema({
    name: String,
    country_of_origin: String,
    color: String
})
mongoose.model('Elephants', ElephantSchema);
var Elephant = mongoose.model('Elephants')

app.use(bodyParser.urlencoded({ extended: true }));

var path = require('path');

app.set('views', path.join(__dirname, './views'));

app.set('view engine', 'ejs');

app.get('/', function(req, res) {
    Elephant.find({}, function(err, elephants){
        if(err){
            console.log("Fail")
        }else{
            res.render('index', {elephants: elephants})
        }
    })
    // res.render('index');
})
// Add User Request 
app.post('/elephant', function(req, res) {
    console.log("POST DATA", req.body);
    var elephant = new Elephant({name: req.body.name, country_of_origin: req.body.country, color: req.body.color});
    elephant.save(function(err){
        if(err){
            console.log('something went wrong');
        }else{
            console.log('success!');
            res.redirect('/')
        }
    })
})

app.post('/process/:id', function(req, res) {
    // console.log("POST DATA", req.body);
    Elephant.update({"_id": req.params.id}, req.body, function(err, response) {
        if(err){
            console.log('something went wrong');
        }else{
            console.log('success!');
            res.redirect('/')
        }
    });
})

app.get('/destroy/:id', function(req,res){
    Elephant.remove({"_id": req.params.id}, function(err, response){
        if(err){ console.log(err)}
        else{
            res.redirect('/')
        }
    })
})


app.get('/elephant/new', function(req, res) {
    res.render('newelephant')
    })

app.get('/elephants/:id', function(req, res){
    // let elephant_id = 
    Elephant.find({"_id": req.params.id}, function(err, elephants){
        if (err){
            console.log("Failure")
        }else{
            res.render ('one_elephant', {elephants: elephants})
        }
    })
    
})

app.get('/edit/:id', function(req, res){
    // let elephant_id = 
    Elephant.find({"_id": req.params.id}, function(err, response){
        if (err){
            console.log("Failure")
        }else{
            res.render('edit', { elephant: response[0]})
        }
    })
    
})

app.listen(8000, function() {
    console.log("listening on port 8000");
})
