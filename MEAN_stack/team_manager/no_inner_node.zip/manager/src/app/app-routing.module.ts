import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PlayersComponent } from './players/players.component';
import { ListComponent } from './list/list.component';
import { AddPlayerComponent } from './add-player/add-player.component';
import { GameTwoComponent } from './game-two/game-two.component';
import { GameThreeComponent } from './game-three/game-three.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: ListComponent,
    children: []
  },
  {
    path: 'add/player',
    pathMatch: 'full',
    component: AddPlayerComponent,
    children: []
  },
  {
    path: 'players',
    pathMatch: 'full',
    component: PlayersComponent,
    children: []
  },
  {
    path: 'gametwo',
    pathMatch: 'full',
    component: GameTwoComponent,
    children: []
  },
  {
    path: 'gamethree',
    pathMatch: 'full',
    component: GameThreeComponent,
    children: []
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
