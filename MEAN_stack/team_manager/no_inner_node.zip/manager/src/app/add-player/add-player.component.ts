import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router'
import {ApiService } from './../api.service'
@Component({
  selector: 'app-add-player',
  templateUrl: './add-player.component.html',
  styleUrls: ['./add-player.component.css']
})
export class AddPlayerComponent implements OnInit {
  newPlayer: object = {
    name: "",
    position: ""
  }
  constructor(private _apiService: ApiService, private _router: Router) { }

  ngOnInit() {
  }

  onSubmit(){
    this._apiService.addPlayer(this.newPlayer)
      .then((data)=>{
        console.log("then", data)
        this.newPlayer = {
          name: "",
          position: ""
        }
        this._router.navigate([''])
      })
      .catch((error)=>{
        console.log("catch", error)
      })
    }
  }


