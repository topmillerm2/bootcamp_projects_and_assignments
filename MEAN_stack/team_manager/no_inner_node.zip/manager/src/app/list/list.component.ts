import { Component, OnInit } from '@angular/core';
import {ApiService } from './../api.service'

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  players = []
  constructor(private _apiService: ApiService) { }

  ngOnInit() {
    this.getAll()
    }

    del(id){
      this._apiService.delPlayer(id)
      .then((data)=>{
        console.log("then", data)
        this.getAll()      
      })
      .catch((error)=>{
        console.log("catch", error)
      })
    }

    getAll(){
      this._apiService.getPlayers()
      .then((data)=>{
        console.log("then", data)
        this.players = data
        // this.getNotes();
      })
      .catch((error)=>{
        console.log("catch", error)
      })
    }
  }

