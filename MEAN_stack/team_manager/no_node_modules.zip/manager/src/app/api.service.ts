import { Injectable } from '@angular/core';
import { Http } from '@angular/http'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
@Injectable()
export class ApiService {

  constructor(private _http: Http) { }

  addPlayer(playerObj){
    console.log(playerObj)
    return this._http.post('/add/player', playerObj).map(Response=>Response.json()).toPromise();
  }

  getPlayers(){
    return this._http.get('/players').map(Response=>Response.json()).toPromise();
  }
  delPlayer(id){
    console.log(id)
    return this._http.delete('/delete/'+id).map(Response=>Response.json()).toPromise();
  }
}
