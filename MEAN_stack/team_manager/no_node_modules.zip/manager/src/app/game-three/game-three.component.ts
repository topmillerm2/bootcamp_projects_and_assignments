import { Component, OnInit } from '@angular/core';
import {ApiService } from './../api.service'
@Component({
  selector: 'app-game-three',
  templateUrl: './game-three.component.html',
  styleUrls: ['./game-three.component.css']
})
export class GameThreeComponent implements OnInit {
  players = []
  constructor(private _apiService: ApiService) { }

  ngOnInit() {
    this._apiService.getPlayers()
      .then((data)=>{
        console.log("then", data)
        this.players = data
        // this.getNotes();
      })
      .catch((error)=>{
        console.log("catch", error)
      })
    }
}
