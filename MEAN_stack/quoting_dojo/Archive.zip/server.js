var express = require('express');

var app = express();

var bodyParser = require('body-parser');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/quoting_dojo')
var UserSchema = new mongoose.Schema({
    name: String,
    quote: String
}, {timestamps: true})
mongoose.model('User', UserSchema);
var User = mongoose.model('User')

app.use(bodyParser.urlencoded({ extended: true }));

var path = require('path');
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request
app.get('/', function(req, res) {
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
    res.render('index');
})
// Add User Request 
app.post('/process', function(req, res) {
    console.log("POST DATA", req.body);
    var user = new User({name: req.body.name, quote: req.body.quote});
    user.save(function(err){
        if(err){
            console.log('something went wrong');
        }else{
            console.log('success!');
            res.redirect('/quotes')
        }
    })
    // res.redirect('/quotes');
})
app.get('/quotes', function(req, res) {
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
    User.find({}, function(err, users){
        if(err){
            console.log("didn't work") 
        }
            res.render('quotes', {users: users})
        })
    })
    // res.render('quotes');

// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})
