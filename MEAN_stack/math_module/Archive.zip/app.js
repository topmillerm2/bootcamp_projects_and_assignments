var math = require('./mathlib')();
console.log(math.add(3,5))
console.log(math.multiply(3,5))
console.log(math.square(3,5))
console.log(math.random(3,13))
