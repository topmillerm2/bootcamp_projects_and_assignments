$(document).ready(function(){
    for(var i=0; i<=400; i++){
        var url = "https://anapioficeandfire.com/api/houses/"+ i;
        house_generate(url,i);
    }

    function house_generate(url,i){
        $.get(url, function(res){
            $('#container').append('<h1 id="name_box" data-house='+ i +'>'+res.name+'</h1>')
        }, "json");
    }

    $(document).on("click", "#name_box",function(){ 
        var house_num = $(this).data("house");
        // console.log(house_num)
        var sec_url ="https://anapioficeandfire.com/api/houses/"+ house_num;
        $.get( sec_url, function(response){
            // var titles = for(var i=0; i<response.titles[i]; i++){}
            htmlBuilder(response);
            }  , "json");
            
            function htmlBuilder(response){
            var htmlStr ='<h2>Name:</h2>' + '<p>'
            htmlStr += response.name + '</p>' + '<h2>Motto: </h2>'+'<p>'
            htmlStr += response.words +'</p>'+ '<h2>Titles:</h2>'

            for(var i=0; i<response.titles.length; i++){
            htmlStr +=  '<ul><li>'+response.titles[i]+ '</li></ul>'
            }
            $('#house_details').html(htmlStr)
            }
            // for(var i=0; i<response.titles[i]; i++){ +})
        });
        
    })
    //names, words, titles
